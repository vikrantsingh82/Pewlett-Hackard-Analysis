-- Select count of actors first names in descending order

-- Select the average duration of movies by rating

-- Select top ten replace costs for the length of the movie

-- Select the count of countries
